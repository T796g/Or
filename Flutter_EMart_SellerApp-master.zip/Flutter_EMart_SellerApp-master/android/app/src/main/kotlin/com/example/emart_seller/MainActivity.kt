package com.example.emart_seller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
