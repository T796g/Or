const appname = "eMart Seller App",
    login = "Login",
    welcome = "Hi, Welcome to",
    email = "Email",
    password = "Password",
    forgotPassword = "Forgot Password",
    anyProblem = "In case of any difficulty, contact administration",
    credit = "@BaabaDevs";
